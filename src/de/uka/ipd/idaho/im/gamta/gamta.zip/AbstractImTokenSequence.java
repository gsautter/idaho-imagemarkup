/*
 * Copyright (c) 2006-, IPD Boehm, Universitaet Karlsruhe (TH) / KIT, by Guido Sautter
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) / KIT nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) / KIT AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package de.uka.ipd.idaho.im.gamta;

import java.util.ArrayList;

import de.uka.ipd.idaho.gamta.Gamta;
import de.uka.ipd.idaho.gamta.Token;
import de.uka.ipd.idaho.gamta.TokenSequence;
import de.uka.ipd.idaho.gamta.Tokenizer;
import de.uka.ipd.idaho.gamta.Tokenizer.CharSequenceToken;
import de.uka.ipd.idaho.gamta.Tokenizer.TokenIterator;
import de.uka.ipd.idaho.gamta.defaultImplementation.AbstractAttributed;
import de.uka.ipd.idaho.im.ImWord;

/**
 * Token sequence overlay for a logical text stream.
 * 
 * @author sautter
 */
public abstract class AbstractImTokenSequence implements ImTokenSequence {
	private ImWord firstWord;
	private ImWord lastWord;
	
	private Tokenizer tokenizer;
	private ArrayList tokens = new ArrayList();
	
	/** Constructor
	 * @param firstWord the word the token sequence starts with
	 * @param tokenizer the tokenizer to use
	 */
	AbstractImTokenSequence(ImWord firstWord, Tokenizer tokenizer) {
		this.firstWord = this.adjustFirstWord(firstWord);
		this.lastWord = this.findLastWord(this.firstWord);
		this.tokenizer = tokenizer;
		
		//	fill token sequence
		ImWord imw = this.firstWord;
		ImTsToken lastToken = null;
		int lastTokenEndOffset = 0;
		while (imw != null) {
			
			//	collect character sequence up to next whitespace
			StringBuffer imwStringBuffer = new StringBuffer();
			ArrayList imWordsAtOffsets = new ArrayList();
			while (true) {
				String imwString = imw.toString();
				imwStringBuffer.append(imwString);
				for (int c = 0; c < imwString.length(); c++)
					imWordsAtOffsets.add(imw);
				if ((imw.getNextRelation() == ImWord.NEXT_RELATION_HYPHENATED) || (imw.getNextRelation() == ImWord.NEXT_RELATION_CONTINUE))
					imw = imw.getNextWord();
				else break;
			}
			
			//	tokenize buffer
			TokenIterator ti = this.tokenizer.getTokenIterator(imwStringBuffer);
			while (ti.hasMoreTokens()) {
				CharSequenceToken cst = ti.getNextToken();
				
				ImWord[] imWordsToOffsets = new ImWord[(cst.endOffset - cst.startOffset) + (ti.hasMoreTokens() ? 0 : 1)];
				for (int o = 0; o < (cst.endOffset - cst.startOffset); o++)
					imWordsToOffsets[o] = ((ImWord) imWordsAtOffsets.get(cst.startOffset + o));
				if (!ti.hasMoreTokens())
					imWordsToOffsets[cst.endOffset - cst.startOffset] = ((ImWord) imWordsAtOffsets.get(cst.endOffset - 1));
				
				ImTsToken imt = new ImTsToken(imwStringBuffer.substring(cst.startOffset, cst.endOffset), lastTokenEndOffset, imWordsToOffsets);
				this.tokens.add(imt);
				
				for (int o = cst.startOffset-1; o > -1; o--) {
					if (imWordsAtOffsets.get(o) == imt.firstWord)
						imt.firstWordStartOffset++;
					else break;
				}
				for (int o = cst.endOffset-1; o > -1; o--) {
					if (imWordsAtOffsets.get(o) == imt.lastWord)
						imt.lastWordEndOffset++;
					else break;
				}
				
				lastTokenEndOffset += imt.value.length();
				lastToken = imt;
			}
			
			//	add whitespace after last token of whitespace free block
			if (imw.getNextRelation() == ImWord.NEXT_RELATION_PARAGRAPH_END) {
				lastToken.whitespace = "\n";
				lastToken.setAttribute(Token.PARAGRAPH_END_ATTRIBUTE, "true");
			}
			else lastToken.whitespace = " ";
			lastTokenEndOffset++;
			
			if (imw == this.lastWord)
				break;
			else imw = imw.getNextWord();
		}
	}
	
	abstract ImWord adjustFirstWord(ImWord firstWord);
	
	abstract ImWord findLastWord(ImWord firstWord);
	
	private static final boolean DEBUG_OFFSET_INDEX_CACHE = true;
	private int lastOffsetTokenIndex = 0;
	synchronized int imTsIndexAtOffset(int offset) {
		if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("TokenizedCharSequence(" + this.hashCode() + "): getting token index at offset " + offset);
		
		//	check for empty token sequence
		if (this.tokens.isEmpty()) {
			if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - before start of first token");
			this.lastOffsetTokenIndex = -1;
			return -1;
		}
		
		//	check for leading and tailing tokens
		if (offset < this.firstImTsToken().startOffset) {
			if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - before start of first token");
			this.lastOffsetTokenIndex = -1;
			return -1;
		}
		if (offset >= this.lastImTsToken().imtEndOffset()) {
			if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - after end of last token");
			this.lastOffsetTokenIndex = -1;
			return this.size();
		}
		
		//	do cache lookup if cached index in range
		if ((this.lastOffsetTokenIndex != -1) && (this.lastOffsetTokenIndex < this.tokens.size())) {
			if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - using cache");
			ImTsToken imt = this.imTsTokenAt(this.lastOffsetTokenIndex);
			
			//	request for same token
			if ((imt.startOffset <= offset) && (offset < imt.imtEndOffset())) {
				if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - cache hit");
				return this.lastOffsetTokenIndex;
			}
			
			//	request for subsequent token
			else if (offset == imt.imtEndOffset()) {
				this.lastOffsetTokenIndex++;
				if (this.lastOffsetTokenIndex == this.tokens.size()) {
					if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - cache at end offset miss");
					this.lastOffsetTokenIndex = -1;
					return this.tokens.size();
				}
				else {
					if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - cache increment hit");
					return this.lastOffsetTokenIndex;
				}
			}
			
			//	request for previous token
			else if (imt.startOffset == (offset + 1)) {
				if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - cache decrement hit");
				this.lastOffsetTokenIndex--;
				return this.lastOffsetTokenIndex;
			}
			else if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - cache miss");
		}
		
		//	use binary search to narrow search interval
		int left = 0;
		int right = this.tokens.size();
		int tIndex = 0;
		ImTsToken imt;
		while ((right - left) > 2) {
			tIndex = ((left + right) / 2);
			imt = this.imTsTokenAt(tIndex);
			if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - tIndex is " + tIndex + ", startOffset is " + imt.startOffset + ", endOffset is " + imt.imtEndOffset());
			if (imt.imtEndOffset() <= offset)
				left = tIndex;
			else if (imt.startOffset <= offset) {
				this.lastOffsetTokenIndex = tIndex;
				return tIndex;
			}
			else right = tIndex;
		}
		if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - tIndex is at least " + left + ", start offset there is " + this.imTsTokenAt(left).startOffset);
		
		//	scan remaining interval
		tIndex = left;
		while (tIndex < this.tokens.size()) {
			imt = this.imTsTokenAt(tIndex);
			if (DEBUG_OFFSET_INDEX_CACHE) System.out.println("   - tIndex is " + tIndex + ", startOffset is " + imt.startOffset + ", endOffset is " + imt.imtEndOffset());
			if (imt.imtEndOffset() <= offset) tIndex++;
			else if (imt.startOffset <= offset) {
				if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - found offset at " + tIndex);
				this.lastOffsetTokenIndex = tIndex;
				return tIndex;
			}
			else tIndex++;
		}
		
		if (DEBUG_OFFSET_INDEX_CACHE) System.out.println(" - end offset exceeded");
		this.lastOffsetTokenIndex = -1;
		return this.tokens.size();
	}
	ImTsToken imTsTokenAt(int index) {
		return ((ImTsToken) this.tokens.get(index));
	}
	ImTsToken firstImTsToken() {
		return ((ImTsToken) this.tokens.get(0));
	}
	ImTsToken lastImTsToken() {
		return ((ImTsToken) this.tokens.get(this.tokens.size()-1));
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.im.gamta.ImTokenSequence#imTokenAt(int)
	 */
	public ImToken imTokenAt(int index) {
		return this.imTsTokenAt(index);
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.im.gamta.ImTokenSequence#firstImToken()
	 */
	public ImToken firstImToken() {
		return this.firstImTsToken();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.im.gamta.ImTokenSequence#lastImToken()
	 */
	public ImToken lastImToken() {
		return this.lastImTsToken();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.CharSequence#length()
	 */
	public int length() {
		ImTsToken lastToken = this.lastImTsToken();
		return (lastToken.startOffset + lastToken.value.length() + lastToken.whitespace.length());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.CharSequence#charAt(int)
	 */
	public char charAt(int offset) {
		int to = this.imTsIndexAtOffset(offset);
		if (to >= this.size())
			return ' ';
		ImTsToken imt = this.imTsTokenAt(to);
		return imt.imtCharAt(offset - imt.startOffset);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.CharSequence#subSequence(int, int)
	 */
	public CharSequence subSequence(int start, int end) {
		StringBuffer subSequence = new StringBuffer();
		int to = this.imTsIndexAtOffset(start);
		if (to == this.tokens.size())
			return "";
		ImTsToken imt = this.imTsTokenAt(to);
		while ((subSequence.length() < (end - start)) && (imt != null)) {
			subSequence.append(imt.imtSubSequence(Math.max(0, (start - imt.startOffset)), Math.min(imt.imtLength(), (end - imt.startOffset))).toString());
			to++;
			imt = ((to == this.tokens.size()) ? null : this.imTsTokenAt(to));
		}
		return subSequence.toString();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#tokenAt(int)
	 */
	public Token tokenAt(int index) {
		return this.imTokenAt(index);
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#firstToken()
	 */
	public Token firstToken() {
		return this.firstImToken();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#lastToken()
	 */
	public Token lastToken() {
		return this.lastImToken();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#valueAt(int)
	 */
	public String valueAt(int index) {
		return this.tokenAt(index).getValue();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#firstValue()
	 */
	public String firstValue() {
		return this.firstToken().getValue();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#lastValue()
	 */
	public String lastValue() {
		return this.lastToken().getValue();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getLeadingWhitespace()
	 */
	public String getLeadingWhitespace() {
		return "";
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getWhitespaceAfter(int)
	 */
	public String getWhitespaceAfter(int index) {
		return this.imTsTokenAt(index).whitespace;
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#size()
	 */
	public int size() {
		return this.tokens.size();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getTokenizer()
	 */
	public Tokenizer getTokenizer() {
		return this.tokenizer;
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getSubsequence(int, int)
	 */
	public TokenSequence getSubsequence(int start, int size) {
		StringBuffer scs = new StringBuffer();
		for (int t = start; t < (start + size); t++) {
			ImTsToken imt = this.imTsTokenAt(t);
			scs.append(imt.value);
			if ((t+1) < (start+size))
				scs.append(imt.whitespace);
		}
		return Gamta.newTokenSequence(scs, this.tokenizer);
	}
	
	/**
	 * A token in a token sequence overlay of a logical text stream
	 * 
	 * @author sautter
	 */
	class ImTsToken extends AbstractAttributed implements ImToken {
		ImWord firstWord;
		int firstWordStartOffset = 0;
		ImWord lastWord;
		int lastWordEndOffset = 0;
		ImWord[] imWordsToOffsets;
		
		String value;
		String whitespace = "";
		int startOffset = 0;
		
		ImTsToken(String value, int startOffset, ImWord[] imWordsToOffsets) {
			this.value = value;
			this.startOffset = startOffset;
			this.firstWord = imWordsToOffsets[0];
			this.lastWord = imWordsToOffsets[imWordsToOffsets.length-1];
			this.imWordsToOffsets = imWordsToOffsets;
		}
		char imtCharAt(int offset) {
			if (offset < this.value.length())
				return this.value.charAt(offset);
			else return this.whitespace.charAt(offset - this.value.length());
		}
		CharSequence imtSubSequence (int start, int end) {
			StringBuffer subSequence = new StringBuffer();
			if (start < this.value.length())
				subSequence.append(this.value.subSequence(start, Math.min(end, this.value.length())).toString());
			if (this.value.length() < end)
				subSequence.append(this.whitespace.subSequence((Math.max(0, (start - this.value.length()))), (end - this.value.length())).toString());
			return subSequence.toString();
		}
		int imtEndOffset() {
			return (this.startOffset + this.imtLength());
		}
		int imtLength() {
			return (this.value.length() + this.whitespace.length());
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.CharSpan#getStartOffset()
		 */
		public int getStartOffset() {
			return this.startOffset;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.CharSpan#getEndOffset()
		 */
		public int getEndOffset() {
			return (this.startOffset + this.value.length());
		}
		/* (non-Javadoc)
		 * @see java.lang.CharSequence#length()
		 */
		public int length() {
			return this.value.length();
		}
		/* (non-Javadoc)
		 * @see java.lang.CharSequence#charAt(int)
		 */
		public char charAt(int index) {
			return ((index < this.value.length()) ? this.value.charAt(index) : this.whitespace.charAt(index - this.value.length()));
		}
		/* (non-Javadoc)
		 * @see java.lang.CharSequence#subSequence(int, int)
		 */
		public CharSequence subSequence(int start, int end) {
			return this.value.subSequence(start, end);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Token#getValue()
		 */
		public String getValue() {
			return this.value;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Token#getTokenizer()
		 */
		public Tokenizer getTokenizer() {
			return tokenizer;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.im.gamta.ImToken#getFirstWord()
		 */
		public ImWord getFirstWord() {
			return this.firstWord;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.im.gamta.ImToken#getFirstWordStartOffset()
		 */
		public int getFirstWordStartOffset() {
			return this.firstWordStartOffset;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.im.gamta.ImToken#getLastWord()
		 */
		public ImWord getLastWord() {
			return this.lastWord;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.im.gamta.ImToken#getLastWordEndOffset()
		 */
		public int getLastWordEndOffset() {
			return this.lastWordEndOffset;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.im.gamta.ImToken#getWhitespaceAfter()
		 */
		public String getWhitespaceAfter() {
			return this.whitespace;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.im.gamta.ImToken#getWordAtOffset(int)
		 */
		public ImWord getWordAtOffset(int offset) {
			return this.imWordsToOffsets[offset];
		}
	}
}