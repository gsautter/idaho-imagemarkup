/*
 * Copyright (c) 2006-, IPD Boehm, Universitaet Karlsruhe (TH) / KIT, by Guido Sautter
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) / KIT nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) / KIT AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package de.uka.ipd.idaho.im.gamta;

import java.io.File;
import java.io.FileInputStream;
import java.util.LinkedList;

import de.uka.ipd.idaho.gamta.Attributed;
import de.uka.ipd.idaho.gamta.Gamta;
import de.uka.ipd.idaho.gamta.Token;
import de.uka.ipd.idaho.gamta.TokenSequence;
import de.uka.ipd.idaho.gamta.Tokenizer;
import de.uka.ipd.idaho.im.ImDocument;
import de.uka.ipd.idaho.im.ImPage;
import de.uka.ipd.idaho.im.ImWord;
import de.uka.ipd.idaho.im.util.ImfIO;

/**
 * Token sequence overlay for a page in an image markup document.
 * 
 * @author sautter
 */
public class ImDocumentPage implements TokenSequence {
	private ImPage page;
	private Tokenizer tokenizer;
	private ImDocumentPageTextStream[] textStreams;
	private int size = 0;
	private int length = 0;
	
	/** Constructor
	 * @param page the page to wrap
	 * @param tokenizer the tokenizer to use
	 */
	public ImDocumentPage(ImPage page, Tokenizer tokenizer) {
		this.page = page;
		this.tokenizer = tokenizer;
		ImWord[] tshs = this.page.getTextStreamHeads();
		LinkedList tstss = new LinkedList();
		for (int h = 0; h < tshs.length; h++) {
			ImPageTokenSequence imts = new ImPageTokenSequence(tshs[h], this.tokenizer);
			tstss.add(new ImDocumentPageTextStream(imts, this.size, this.length));
			this.size += imts.size();
			this.length += imts.length();
		}
		this.textStreams = ((ImDocumentPageTextStream[]) tstss.toArray(new ImDocumentPageTextStream[tstss.size()]));
	}
	
	/**
	 * Retrieve the image markup document page wrapped in this object.
	 * @return the wrapped image markup document page
	 */
	public ImPage getPage() {
		return this.page;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.CharSequence#length()
	 */
	public int length() {
		return this.length;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.CharSequence#charAt(int)
	 */
	public char charAt(int offset) {
		for (int ts = 0; ts < this.textStreams.length; ts++) {
			if (offset < this.textStreams[ts].endOffset)
				return this.textStreams[ts].tokens.charAt(offset - this.textStreams[ts].startOffset);
		}
		return ' ';
	}
	
	/* (non-Javadoc)
	 * @see java.lang.CharSequence#subSequence(int, int)
	 */
	public CharSequence subSequence(int start, int end) {
		StringBuffer subSequence = new StringBuffer();
		for (int ts = 0; ts < this.textStreams.length; ts++) {
			if ((start < this.textStreams[ts].endOffset) && (this.textStreams[ts].startOffset < end))
				subSequence.append(this.textStreams[ts].tokens.subSequence(Math.max(0, (start - this.textStreams[ts].startOffset)), Math.min(this.textStreams[ts].tokens.length(), (end - this.textStreams[ts].startOffset))));
		}
		return subSequence.toString();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#tokenAt(int)
	 */
	public Token tokenAt(int index) {
		for (int ts = 0; ts < this.textStreams.length; ts++) {
			if (index < this.textStreams[ts].endIndex)
				return new ImDocumentPageToken(this.textStreams[ts].tokens.tokenAt(index - this.textStreams[ts].startIndex), (this.textStreams[ts].startOffset));
		}
		throw new ArrayIndexOutOfBoundsException(index);
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#firstToken()
	 */
	public Token firstToken() {
		return this.textStreams[0].tokens.firstToken();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#lastToken()
	 */
	public Token lastToken() {
		return this.textStreams[this.textStreams.length-1].tokens.lastToken();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#valueAt(int)
	 */
	public String valueAt(int index) {
		return this.tokenAt(index).getValue();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#firstValue()
	 */
	public String firstValue() {
		return this.firstToken().getValue();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#lastValue()
	 */
	public String lastValue() {
		return this.lastToken().getValue();
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getLeadingWhitespace()
	 */
	public String getLeadingWhitespace() {
		return "";
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getWhitespaceAfter(int)
	 */
	public String getWhitespaceAfter(int index) {
		for (int ts = 0; ts < this.textStreams.length; ts++) {
			if (index < this.textStreams[ts].endIndex)
				return this.textStreams[ts].tokens.getWhitespaceAfter(index - this.textStreams[ts].startIndex);
		}
		throw new ArrayIndexOutOfBoundsException(index);
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#size()
	 */
	public int size() {
		return this.size;
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getTokenizer()
	 */
	public Tokenizer getTokenizer() {
		return this.tokenizer;
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getSubsequence(int, int)
	 */
	public TokenSequence getSubsequence(int start, int size) {
		StringBuffer scs = new StringBuffer();
		for (int ts = 0; ts < this.textStreams.length; ts++)
			if ((start < this.textStreams[ts].endIndex) && (this.textStreams[ts].startIndex < (start + size))) {
				scs.append(this.textStreams[ts].tokens.getSubsequence(Math.max(0, (start - this.textStreams[ts].startIndex)), Math.min(this.textStreams[ts].tokens.size(), ((start + size) - this.textStreams[ts].startIndex))));
				if (this.textStreams[ts].endIndex < (start + size))
					scs.append(this.textStreams[ts].tokens.getWhitespaceAfter(this.textStreams[ts].tokens.size() - 1));
			}
		return Gamta.newTokenSequence(scs, this.tokenizer);
	}
	
	private class ImDocumentPageTextStream {
		ImPageTokenSequence tokens;
		int startIndex;
		int endIndex;
		int startOffset;
		int endOffset;
		ImDocumentPageTextStream(ImPageTokenSequence imts, int startIndex, int startOffset) {
			this.tokens = imts;
			this.startIndex = startIndex;
			this.endIndex = (this.startIndex + this.tokens.size());
			this.startOffset = startOffset;
			this.endOffset = (this.startOffset + this.tokens.length());
		}
	}
	
	private class ImDocumentPageToken implements Token {
		private Token token;
		private int offsetShift;
		ImDocumentPageToken(Token token, int offsetShift) {
			super();
			this.token = token;
			this.offsetShift = offsetShift;
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#setAttribute(java.lang.String)
		 */
		public void setAttribute(String name) {
			this.token.setAttribute(name);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#setAttribute(java.lang.String, java.lang.Object)
		 */
		public Object setAttribute(String name, Object value) {
			return this.token.setAttribute(name, value);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#copyAttributes(de.uka.ipd.idaho.gamta.Attributed)
		 */
		public void copyAttributes(Attributed source) {
			this.token.copyAttributes(source);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#getAttribute(java.lang.String)
		 */
		public Object getAttribute(String name) {
			return this.getAttribute(name);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#getAttribute(java.lang.String, java.lang.Object)
		 */
		public Object getAttribute(String name, Object def) {
			return this.token.getAttribute(name, def);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#hasAttribute(java.lang.String)
		 */
		public boolean hasAttribute(String name) {
			return this.token.hasAttribute(name);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#getAttributeNames()
		 */
		public String[] getAttributeNames() {
			return this.token.getAttributeNames();
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#removeAttribute(java.lang.String)
		 */
		public Object removeAttribute(String name) {
			return this.token.removeAttribute(name);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Attributed#clearAttributes()
		 */
		public void clearAttributes() {
			this.token.clearAttributes();
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.CharSpan#getStartOffset()
		 */
		public int getStartOffset() {
			return (this.token.getStartOffset() + this.offsetShift);
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.CharSpan#getEndOffset()
		 */
		public int getEndOffset() {
			return (this.token.getEndOffset() + this.offsetShift);
		}
		/* (non-Javadoc)
		 * @see java.lang.CharSequence#length()
		 */
		public int length() {
			return this.token.length();
		}
		/* (non-Javadoc)
		 * @see java.lang.CharSequence#charAt(int)
		 */
		public char charAt(int index) {
			return this.token.charAt(index - this.offsetShift);
		}
		/* (non-Javadoc)
		 * @see java.lang.CharSequence#subSequence(int, int)
		 */
		public CharSequence subSequence(int start, int end) {
			return this.token.subSequence((start - this.offsetShift), (end - this.offsetShift));
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Token#getValue()
		 */
		public String getValue() {
			return this.token.getValue();
		}
		/* (non-Javadoc)
		 * @see de.uka.ipd.idaho.gamta.Token#getTokenizer()
		 */
		public Tokenizer getTokenizer() {
			return this.token.getTokenizer();
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		final File baseFolder = new File("E:/Testdaten/PdfExtract/");
		final String pdfName = "dikow_2012.pdf";
		
		ImDocument imDoc = ImfIO.loadDocument(new FileInputStream(new File(baseFolder, (pdfName + ".imf"))));
		ImPage[] imPages = imDoc.getPages();
		for (int p = 0; p < imPages.length; p++) {
			ImWord[] tshs = imPages[p].getTextStreamHeads();
			for (int h = 0; h < tshs.length; h++) {
				for (ImWord imw = tshs[h]; imw != null; imw = imw.getNextWord()) {
					if (imw.pageId != p)
						break;
					if (imw.getString().endsWith("�"))
						imw.setNextRelation(ImWord.NEXT_RELATION_HYPHENATED);
				}
			}
		}
		for (int p = 0; p < imPages.length; p++) {
			if (p != 0)
				continue;
			ImDocumentPage imdp = new ImDocumentPage(imPages[p], Gamta.INNER_PUNCTUATION_TOKENIZER);
			for (int t = 0; t < imdp.size(); t++) {
				Token token = imdp.tokenAt(t);
				System.out.println(token.getStartOffset() + ": " + token.getValue());
			}
		}
	}
}