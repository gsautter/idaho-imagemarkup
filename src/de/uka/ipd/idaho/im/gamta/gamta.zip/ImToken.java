/*
 * Copyright (c) 2006-, IPD Boehm, Universitaet Karlsruhe (TH) / KIT, by Guido Sautter
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) / KIT nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) / KIT AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package de.uka.ipd.idaho.im.gamta;

import de.uka.ipd.idaho.gamta.Token;
import de.uka.ipd.idaho.im.ImWord;

/**
 * A token in a logical text stream overlay.
 * 
 * @author sautter
 */
public interface ImToken extends Token {

	/**
	 * Retrieve the first word from the underlying image markup document
	 * (part of) whose value is spanned by this token.
	 * @return the first spanned word
	 */
	public abstract ImWord getFirstWord();

	/**
	 * Retrieve the start offset of the token's value in the string value
	 * of the first spanned word.
	 * @return the start offset of the token in the first spanned word
	 */
	public abstract int getFirstWordStartOffset();

	/**
	 * Retrieve the last word from the underlying image markup document
	 * (part of) whose value is spanned by this token.
	 * @return the last spanned word
	 */
	public abstract ImWord getLastWord();

	/**
	 * Retrieve the end offset of the token's value in the string value of
	 * the last spanned word.
	 * @return the end offset of the token in the last spanned word
	 */
	public abstract int getLastWordEndOffset();

	/**
	 * Retrieve the whitespace following the value of the token. The length
	 * of the whitespace is either 0 or 1. In the latter case, the returned
	 * string consists of a single space or line break character.
	 * @return the whitespace following the value of the token
	 */
	public abstract String getWhitespaceAfter();

	/**
	 * Retrieve the image markup word at a given offset in the token.
	 * @param offset the offset to find the word for
	 * @return the image markup word at the argument offset
	 */
	public abstract ImWord getWordAtOffset(int offset);

}