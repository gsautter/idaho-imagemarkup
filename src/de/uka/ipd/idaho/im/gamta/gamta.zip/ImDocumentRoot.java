/*
 * Copyright (c) 2006-, IPD Boehm, Universitaet Karlsruhe (TH) / KIT, by Guido Sautter
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) / KIT nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) / KIT AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package de.uka.ipd.idaho.im.gamta;

import de.uka.ipd.idaho.gamta.Annotation;
import de.uka.ipd.idaho.gamta.AnnotationListener;
import de.uka.ipd.idaho.gamta.CharSequenceListener;
import de.uka.ipd.idaho.gamta.DocumentRoot;
import de.uka.ipd.idaho.gamta.MutableAnnotation;
import de.uka.ipd.idaho.gamta.MutableCharSequence;
import de.uka.ipd.idaho.gamta.MutableTokenSequence;
import de.uka.ipd.idaho.gamta.QueriableAnnotation;
import de.uka.ipd.idaho.gamta.Token;
import de.uka.ipd.idaho.gamta.TokenSequence;
import de.uka.ipd.idaho.gamta.TokenSequenceListener;
import de.uka.ipd.idaho.gamta.Tokenizer;
import de.uka.ipd.idaho.gamta.defaultImplementation.AbstractAttributed;
import de.uka.ipd.idaho.im.ImDocument;

/**
 * This wrapper class lets an image markup document act as a normal GAMTA
 * document, facilitating application of analysis logic working with the
 * latter.
 * 
 * @author sautter
 */
public class ImDocumentRoot extends AbstractAttributed implements DocumentRoot {
	
	/* TODO building this:
	 * - line up words, depending on serialization mode
	 * - wrap words into token, one or more words per token
	 *   - also store start offset and string length, as well as subsequent whitespace
	 *   - with more than one word, map token chars (or groups thereof) to words to aid text modification
	 *   - also store token index to have it available for annotations
	 * - get all existing annotations
	 * - represent annotations as objects pointing to their first an last word, and the source annotation object
	 * - get all existing regions
	 * - represent regions whose words all belong to the same text stream as annotations
	 */
	
	/* TODO built-in attributes:
	 * - tokenizer from respective attribute of underlying document
	 * - pageId and page number from underlying page (lastPageId and last page number accordingly)
	 * - bounding box
	 * - page image name and resolution
	 */
	
	/* TODO handling char sequence modifications:
	 * - in token objects, map each char of the token value to the underlying word it comes from (simple array or list, every position filled with the word the corresponding car comes from)
	 * - removing char:
	 *   - adjust mapping, as well as offsets, the latter for all subsequent tokens as well
	 *   - adjust string of word the char came from
	 *   - if word ends up empty, cut it out of word sequence, but don't remove it from document (or maybe do remove it)
	 * - replacing a char: adjust string of word the char came from
	 * 
	 * - tokenization changes:
	 *   - check if tokenization changes in any kind of way
	 *   - if so, split up or merge token objects ...
	 *   - ... and update offsets and indexes in all subsequent words as well
	 */
	
	/* TODO handling annotations:
	 * - adding: get tokens from array, and from them underlying words, then add annotation to document and represent as above
	 * - removing actual annotations: simply remove
	 * - removing annotations that are actually regions: dito
	 * - modifying attributes: simply do it
	 * 
	 * - work with view objects for cascading, just as in other implementation
	 */
	
	/* TODO:
	 * - implement token sequence overlay first
	 *   - get all text stream heads from document
	 *   - store all text stream heads by page they start on
	 *   - start token sequence with first stream in first page
	 *   - run through stream
	 *     - end on same page --> simply append next stream (in same or next page)
	 *     - runs on to next page --> insert all pending streams after first paragraph ending word in running stream
	 *   - index word lengths for char sequence methods, as in GAMTA default implementation
	 *   - consider using one token sequence object per text stream and page, to introduce second layer of indexing, speeding up search
	 * - implement mutable token sequence overlay second
	 *   - anchor tokens to words (might be multiple words per token, and multiple tokens per word)
	 *     - give token implementation firstWord() and lastWord() methods
	 *     - somehow bundle tokens based in the same word to help handling annotation starting/ending in mid word rather than at boundary
	 *   - handle character and token replacements with Levenshtein transformation
	 * - add retrieving annotations using getAnnotati<onsAt()
	 *   --> ... or better use index data structure
	 *   - consider making regions available this way as well
	 * - add adding / removing annotations using the words tokens are anchored to
	 */
	
	/* TODO create constructor with four-way switch:
	 * - completely un-normalized: generate overlay strictly page by page, and stream head by stream head (GG before page normalization)
	 *   - show pages, columns, blocks, and layout paragraphs as annotations
	 * - un-normalized de-hyphenated: generate overlay strictly page by page, but include hyphenated and continued words from subsequent pages
	 *   - show pages, columns, blocks, and layout paragraphs as annotations, pulling in and leaving out tail and lead parts words of multi-word tokens, respectively
	 *   - show logical detail annotations
	 * - normalized mixed: generate overlay page by page, but complete paragraphs before inserting other streams (GG after page normalization)
	 *   - show logical structure and detail annotations
	 * - normalized through: generate overlay strictly one stream after the other
	 *   - show logical structure and detail annotations
	 * 
	 * TODO use the same constructor options for ImTokenSequence (and revert it to concrete class), doing away with two marginally different sub classes:
	 * - completely un-normalized: generate overlay strictly within page, stream head by stream head (GG page before page normalization)
	 * - un-normalized de-hyphenated: generate overlay strictly page by page, but include hyphenated and continues words from subsequent pages
	 * - normalized mixed: generate overlay page by page, but complete paragraphs before inserting other streams (GG after page normalization)
	 * - normalized through: generate overlay strictly one stream after the other
	 */
	
	private ImDocument imDoc;
	
	/** Constructor
	 * @param imDoc the image markup document to wrap
	 */
	public ImDocumentRoot(ImDocument imDoc) {
		this.imDoc = imDoc;
	}
	
	/**
	 * Retrieve the image markup document wrapped in this object.
	 * @return the wrapped image markup document
	 */
	public ImDocument getPage() {
		return this.imDoc;
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#addAnnotation(de.uka.ipd.idaho.gamta.Annotation)
	 */
	public MutableAnnotation addAnnotation(Annotation annotation) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#addAnnotation(java.lang.String, int, int)
	 */
	public MutableAnnotation addAnnotation(String type, int startIndex, int size) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#removeAnnotation(de.uka.ipd.idaho.gamta.Annotation)
	 */
	public Annotation removeAnnotation(Annotation annotation) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#removeTokens(de.uka.ipd.idaho.gamta.Annotation)
	 */
	public TokenSequence removeTokens(Annotation annotation) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#getMutableAnnotations()
	 */
	public MutableAnnotation[] getMutableAnnotations() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#getMutableAnnotations(java.lang.String)
	 */
	public MutableAnnotation[] getMutableAnnotations(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#addAnnotationListener(de.uka.ipd.idaho.gamta.AnnotationListener)
	 */
	public void addAnnotationListener(AnnotationListener al) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableAnnotation#removeAnnotationListener(de.uka.ipd.idaho.gamta.AnnotationListener)
	 */
	public void removeAnnotationListener(AnnotationListener al) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.QueriableAnnotation#getAbsoluteStartIndex()
	 */
	public int getAbsoluteStartIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.QueriableAnnotation#getAbsoluteStartOffset()
	 */
	public int getAbsoluteStartOffset() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.QueriableAnnotation#getAnnotations()
	 */
	public QueriableAnnotation[] getAnnotations() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.QueriableAnnotation#getAnnotations(java.lang.String)
	 */
	public QueriableAnnotation[] getAnnotations(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.QueriableAnnotation#getAnnotationTypes()
	 */
	public String[] getAnnotationTypes() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.QueriableAnnotation#getAnnotationNestingOrder()
	 */
	public String getAnnotationNestingOrder() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getStartIndex()
	 */
	public int getStartIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getEndIndex()
	 */
	public int getEndIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getType()
	 */
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#changeTypeTo(java.lang.String)
	 */
	public String changeTypeTo(String newType) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getAnnotationID()
	 */
	public String getAnnotationID() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getValue()
	 */
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#toXML()
	 */
	public String toXML() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#tokenAt(int)
	 */
	public Token tokenAt(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#firstToken()
	 */
	public Token firstToken() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#lastToken()
	 */
	public Token lastToken() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#valueAt(int)
	 */
	public String valueAt(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#firstValue()
	 */
	public String firstValue() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#lastValue()
	 */
	public String lastValue() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getLeadingWhitespace()
	 */
	public String getLeadingWhitespace() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getWhitespaceAfter(int)
	 */
	public String getWhitespaceAfter(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#size()
	 */
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getTokenizer()
	 */
	public Tokenizer getTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.TokenSequence#getSubsequence(int, int)
	 */
	public TokenSequence getSubsequence(int start, int size) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see java.lang.CharSequence#length()
	 */
	public int length() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see java.lang.CharSequence#charAt(int)
	 */
	public char charAt(int index) {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see java.lang.CharSequence#subSequence(int, int)
	 */
	public CharSequence subSequence(int start, int end) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.CharSpan#getStartOffset()
	 */
	public int getStartOffset() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.CharSpan#getEndOffset()
	 */
	public int getEndOffset() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#setLeadingWhitespace(java.lang.CharSequence)
	 */
	public CharSequence setLeadingWhitespace(CharSequence whitespace) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#setValueAt(java.lang.CharSequence, int)
	 */
	public CharSequence setValueAt(CharSequence value, int index) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#setWhitespaceAfter(java.lang.CharSequence, int)
	 */
	public CharSequence setWhitespaceAfter(CharSequence whitespace, int index) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#removeTokensAt(int, int)
	 */
	public TokenSequence removeTokensAt(int index, int size) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#insertTokensAt(java.lang.CharSequence, int)
	 */
	public CharSequence insertTokensAt(CharSequence tokens, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#addTokens(java.lang.CharSequence)
	 */
	public CharSequence addTokens(CharSequence tokens) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#clear()
	 */
	public void clear() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#getMutableSubsequence(int, int)
	 */
	public MutableTokenSequence getMutableSubsequence(int start, int size) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#addTokenSequenceListener(de.uka.ipd.idaho.gamta.TokenSequenceListener)
	 */
	public void addTokenSequenceListener(TokenSequenceListener tsl) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableTokenSequence#removeTokenSequenceListener(de.uka.ipd.idaho.gamta.TokenSequenceListener)
	 */
	public void removeTokenSequenceListener(TokenSequenceListener tsl) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#addChar(char)
	 */
	public void addChar(char ch) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#addChars(java.lang.CharSequence)
	 */
	public void addChars(CharSequence chars) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#insertChar(char, int)
	 */
	public void insertChar(char ch, int offset) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#insertChars(java.lang.CharSequence, int)
	 */
	public void insertChars(CharSequence chars, int offset) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#removeChar(int)
	 */
	public char removeChar(int offset) {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#removeChars(int, int)
	 */
	public CharSequence removeChars(int offset, int length) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#setChar(char, int)
	 */
	public char setChar(char ch, int offset) {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#setChars(java.lang.CharSequence, int, int)
	 */
	public CharSequence setChars(CharSequence chars, int offset, int length) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#mutableSubSequence(int, int)
	 */
	public MutableCharSequence mutableSubSequence(int start, int end) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#addCharSequenceListener(de.uka.ipd.idaho.gamta.CharSequenceListener)
	 */
	public void addCharSequenceListener(CharSequenceListener csl) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.MutableCharSequence#removeCharSequenceListener(de.uka.ipd.idaho.gamta.CharSequenceListener)
	 */
	public void removeCharSequenceListener(CharSequenceListener csl) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.DocumentRoot#setAnnotationNestingOrder(java.lang.String)
	 */
	public String setAnnotationNestingOrder(String ano) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getDocumentProperty(java.lang.String)
	 */
	public String getDocumentProperty(String propertyName) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getDocumentProperty(java.lang.String, java.lang.String)
	 */
	public String getDocumentProperty(String propertyName, String defaultValue) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.Annotation#getDocumentPropertyNames()
	 */
	public String[] getDocumentPropertyNames() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.DocumentRoot#setDocumentProperty(java.lang.String, java.lang.String)
	 */
	public String setDocumentProperty(String propertyName, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.DocumentRoot#removeDocumentProperty(java.lang.String)
	 */
	public String removeDocumentProperty(String propertyName) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.DocumentRoot#clearDocumentProperties()
	 */
	public void clearDocumentProperties() {
		// TODO Auto-generated method stub

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}