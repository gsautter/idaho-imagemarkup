/*
 * Copyright (c) 2006-, IPD Boehm, Universitaet Karlsruhe (TH) / KIT, by Guido Sautter
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) / KIT nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) / KIT AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package de.uka.ipd.idaho.im.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.font.TextLayout;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JViewport;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

import de.uka.ipd.idaho.easyIO.settings.Settings;
import de.uka.ipd.idaho.gamta.AnnotationUtils;
import de.uka.ipd.idaho.gamta.util.ControllingProgressMonitor;
import de.uka.ipd.idaho.gamta.util.GenericGamtaXML;
import de.uka.ipd.idaho.gamta.util.imaging.ImagingConstants;
import de.uka.ipd.idaho.gamta.util.imaging.PageImage;
import de.uka.ipd.idaho.gamta.util.imaging.PageImageInputStream;
import de.uka.ipd.idaho.gamta.util.imaging.PageImageStore;
import de.uka.ipd.idaho.gamta.util.imaging.PageImageStore.AbstractPageImageStore;
import de.uka.ipd.idaho.gamta.util.swing.ProgressMonitorPanel;
import de.uka.ipd.idaho.goldenGate.CustomFunction;
import de.uka.ipd.idaho.goldenGate.GoldenGATE;
import de.uka.ipd.idaho.goldenGate.GoldenGateConfiguration;
import de.uka.ipd.idaho.goldenGate.GoldenGateConstants;
import de.uka.ipd.idaho.goldenGate.configuration.FileConfiguration;
import de.uka.ipd.idaho.goldenGate.plugins.DocumentProcessor;
import de.uka.ipd.idaho.goldenGate.plugins.DocumentProcessorManager;
import de.uka.ipd.idaho.goldenGate.plugins.GoldenGatePlugin;
import de.uka.ipd.idaho.goldenGate.util.ResourceDialog;
import de.uka.ipd.idaho.im.ImAnnotation;
import de.uka.ipd.idaho.im.ImDocument;
import de.uka.ipd.idaho.im.ImDocument.ImDocumentListener;
import de.uka.ipd.idaho.im.ImObject;
import de.uka.ipd.idaho.im.ImRegion;
import de.uka.ipd.idaho.im.ImWord;
import de.uka.ipd.idaho.im.gamta.ImDocumentRoot;
import de.uka.ipd.idaho.im.pdf.PdfExtractor;
import de.uka.ipd.idaho.im.util.ImDocumentMarkupPanel;
import de.uka.ipd.idaho.im.util.ImDocumentMarkupPanel.TwoClickActionMessenger;
import de.uka.ipd.idaho.im.util.ImDocumentMarkupPanel.TwoClickSelectionAction;
import de.uka.ipd.idaho.im.util.ImfIO;

/**
 * @author sautter
 *
 */
public class ImDocumentEditor implements ImagingConstants, GoldenGateConstants {
	
	private static final String LOG_TIMESTAMP_DATE_FORMAT = "yyyyMMdd-HHmm";
	private static final DateFormat LOG_TIMESTAMP_FORMATTER = new SimpleDateFormat(LOG_TIMESTAMP_DATE_FORMAT);
	
	private ImDocumentEditor() {}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
		//	set platform L&F
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {}
		
		//	get base path
		File path = new File(".");
		
		//	load own configuration (text stream, annotation, and region type colors, etc.)
		Settings config = Settings.loadSettings(new File(path, "GgImagine.cnfg"));
		
		//	adjust basic parameters
		String logFileName = ("GgImagine." + LOG_TIMESTAMP_FORMATTER.format(new Date()) + ".log");
		
		//	parse remaining args
		for (int a = 1; a < args.length; a++) {
			String arg = args[a];
			if (arg != null) {
				if (arg.equals(LOG_PARAMETER + "=IDE") || arg.equals(LOG_PARAMETER + "=NO"))
					logFileName = null;
				else if (arg.startsWith(LOG_PARAMETER + "="))
					logFileName = arg.substring((LOG_PARAMETER + "=").length());
			}
		}
		
		//	create log files if required
		File logFolder = null;
		File logFileOut = null;
		File logFileErr = null;
		if (logFileName != null) try {
			
			//	truncate log file extension
			if (logFileName.endsWith(".log"))
				logFileName = logFileName.substring(0, (logFileName.length() - ".log".length()));
			
			//	create absolute log files
			if (logFileName.startsWith("/") || (logFileName.indexOf(':') != -1)) {
				logFileOut = new File(logFileName + ".out.log");
				logFileErr = new File(logFileName + ".err.log");
				logFolder = logFileOut.getAbsoluteFile().getParentFile();
			}
			
			//	create relative log files (the usual case)
			else {
				
				//	get log path
				logFolder = new File(path, LOG_FOLDER_NAME);
				logFolder = logFolder.getAbsoluteFile();
				logFolder.mkdirs();
				
				//	create log files
				logFileOut = new File(logFolder, (logFileName + ".out.log"));
				logFileErr = new File(logFolder, (logFileName + ".err.log"));
			}
			
			//	redirect System.out
			logFileOut.getParentFile().mkdirs();
			logFileOut.createNewFile();
			System.setOut(new PrintStream(new BufferedOutputStream(new FileOutputStream(logFileOut)), true, "UTF-8"));
			
			//	redirect System.err
			logFileErr.getParentFile().mkdirs();
			logFileErr.createNewFile();
			System.setErr(new PrintStream(new BufferedOutputStream(new FileOutputStream(logFileErr)), true, "UTF-8"));
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Could not create log files in folder '" + logFolder.getAbsolutePath() + "'." +
					"\nCommon reasons are a full hard drive, lack of write permissions to the folder, or system protection software." +
					"\nUse the 'Configure' button in the configuration selector dialog to select a different log location." +
					"\nThen exit and re-start GoldenGATE Imagine to apply the change." +
					"\n\nNote that you can work normally without the log files, it's just that in case of an error, there are" +
					"\nno log files to to help investigate what exactly went wrong and help developers fix the problem.", "Error Creating Log Files", JOptionPane.ERROR_MESSAGE);
		}
		
		//	load GG core from some configuration
		String ggConfigName = config.getSetting("ggConfigName");
		GoldenGateConfiguration ggConfig = new FileConfiguration(ggConfigName, new File(path, (GoldenGateConstants.CONFIG_FOLDER_NAME + "/" + ggConfigName)), false, true);
		final GoldenGATE gg = GoldenGATE.openGoldenGATE(ggConfig, false);
		
		//	create UI
		final ImDocumentEditorUI ui = new ImDocumentEditorUI(("GoldenGATE Imagine - " + ggConfig.getName()), config, new File("E:/Testdaten/PdfExtract/"));
		ui.setIconImage(ggConfig.getIconImage());
		
		//	add document processor menu
		JMenu toolsMenu = new JMenu("Tools");
		GoldenGatePlugin[] ggPlugins = gg.getPlugins();
		for (int p = 0; p < ggPlugins.length; p++) {
			System.out.println("Investigating plugin " + ggPlugins[p].getClass().getName());
			if (ggPlugins[p] instanceof DocumentProcessorManager) {
				final DocumentProcessorManager dpm = ((DocumentProcessorManager) ggPlugins[p]);
				if (dpm.getToolsMenuLabel() == null)
					continue;
				JMenuItem mi = new JMenuItem(dpm.getToolsMenuLabel() + " " + dpm.getResourceTypeLabel());
				mi.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ae) {
						ImDocumentEditorTab idet = ui.getActiveDocument();
						if (idet == null)
							return;
						ResourceDialog dpSelector = ResourceDialog.getResourceDialog(ui, dpm, ("Select " + dpm.getResourceTypeLabel() + " to " + dpm.getToolsMenuLabel()), dpm.getToolsMenuLabel());
						dpSelector.setVisible(true);
						String dpName = dpSelector.getSelectedResourceName();
						if (dpName == null)
							return;
						DocumentProcessor dp = dpm.getDocumentProcessor(dpName);
						if (dp == null)
							return;
						idet.applyDocumentProcessor(dp);
					}
				});
				toolsMenu.add(mi);
			}
		}
		for (int p = 0; p < ggPlugins.length; p++)
			if (ggPlugins[p] instanceof CustomFunction.Manager) {
				CustomFunction.Manager cfm = ((CustomFunction.Manager) ggPlugins[p]);
				String[] cfns = cfm.getResourceNames();
				if ((cfns.length != 0) && (toolsMenu.getMenuComponentCount() != 0))
					toolsMenu.addSeparator();
				for (int n = 0; n < cfns.length; n++) {
					final CustomFunction cf = cfm.getCustomFunction(cfns[n]);
					if (cf == null)
						continue;
					JMenuItem mi = new JMenuItem(cf.label);
					mi.setToolTipText(cf.toolTip);
					mi.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent ae) {
							ImDocumentEditorTab idet = ui.getActiveDocument();
							if (idet == null)
								return;
							DocumentProcessor dp = gg.getDocumentProcessorForName(cf.getDocumentProcessorName());
							if (dp == null)
								return;
							idet.applyDocumentProcessor(dp);
						}
					});
					toolsMenu.add(mi);
				}
			}
		if (toolsMenu.getMenuComponentCount() != 0)
			ui.addMenu(toolsMenu);
		
		//	build drop target
		DropTarget dropTarget = new DropTarget(ui, new DropTargetAdapter() {
			public void drop(DropTargetDropEvent dtde) {
				dtde.acceptDrop(dtde.getDropAction());
				Transferable transfer = dtde.getTransferable();
				DataFlavor[] dataFlavors = transfer.getTransferDataFlavors();
				for (int d = 0; d < dataFlavors.length; d++) {
					System.out.println(dataFlavors[d].toString());
					System.out.println(dataFlavors[d].getRepresentationClass());
					try {
						Object transferData = transfer.getTransferData(dataFlavors[d]);
						System.out.println(transferData.getClass().getName());
						
						List transferList = ((List) transferData);
						if (transferList.isEmpty())
							return;
						
						for (int t = 0; t < transferList.size(); t++) {
							File droppedFile = ((File) transferList.get(t));
							try {
								FileFilter matchFileFilter;
								if (imfFileFilter.accept(droppedFile))
									matchFileFilter = imfFileFilter;
								else if (genericPdfFileFilter.accept(droppedFile))
									matchFileFilter = genericPdfFileFilter;
								else continue;
								InputStream in = new BufferedInputStream(new FileInputStream(droppedFile));
								ui.loadDocument(droppedFile, matchFileFilter, in);
								in.close();
							}
							catch (IOException ioe) {
								System.out.println("Error opening document '" + droppedFile.getAbsolutePath() + "':\n   " + ioe.getClass().getName() + " (" + ioe.getMessage() + ")");
								ioe.printStackTrace(System.out);
								JOptionPane.showMessageDialog(ui, ("Could not open file '" + droppedFile.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Opening File", JOptionPane.ERROR_MESSAGE);
							}
							catch (SecurityException se) {
								System.out.println("Error opening document '" + droppedFile.getName() + "':\n   " + se.getClass().getName() + " (" + se.getMessage() + ")");
								se.printStackTrace(System.out);
								JOptionPane.showMessageDialog(ui, ("Not allowed to open file '" + droppedFile.getName() + "':\n" + se.getMessage() + "\n\nIf you are currently running GoldenGATE Editor as an applet, your\nbrowser's security mechanisms might prevent reading files from your local disc."), "Not Allowed To Open File", JOptionPane.ERROR_MESSAGE);
								return;
							}
						}
					}
					catch (UnsupportedFlavorException ufe) {
						ufe.printStackTrace(System.out);
					}
					catch (IOException ioe) {
						ioe.printStackTrace(System.out);
					}
					catch (Exception e) {
						e.printStackTrace(System.out);
					}
				}
			}
		});
		dropTarget.setActive(true);
		
		//	show UI
		ui.setVisible(true);
	}
	
	private static final FileFilter imfFileFilter = new FileFilter() {
		public boolean accept(File file) {
			return (file.isDirectory() || file.getName().toLowerCase().endsWith(".imf"));
		}
		public String getDescription() {
			return "Image Markup Files";
		}
	};
	private static final FileFilter genericPdfFileFilter = new FileFilter() {
		public boolean accept(File file) {
			return (file.isDirectory() || file.getName().toLowerCase().endsWith(".pdf"));
		}
		public String getDescription() {
			return "PDF Documents";
		}
	};
	private static final FileFilter textPdfFileFilter = new FileFilter() {
		public boolean accept(File file) {
			return (file.isDirectory() || file.getName().toLowerCase().endsWith(".pdf"));
		}
		public String getDescription() {
			return "PDF Documents (born-digital)";
		}
	};
	private static final FileFilter imagePdfFileFilter = new FileFilter() {
		public boolean accept(File file) {
			return (file.isDirectory() || file.getName().toLowerCase().endsWith(".pdf"));
		}
		public String getDescription() {
			return "PDF Documents (scanned)";
		}
	};
	private static final FileFilter xmlFileFilter = new FileFilter() {
		public boolean accept(File file) {
			return (file.isDirectory() || file.getName().toLowerCase().endsWith(".xml"));
		}
		public String getDescription() {
			return "XML Documents";
		}
	};
	private static void clearFileFilters(JFileChooser fileChooser) {
		FileFilter[] fileFilters = fileChooser.getChoosableFileFilters();
		for (int f = 0; f < fileFilters.length; f++)
			fileChooser.removeChoosableFileFilter(fileFilters[f]);
	}
	
	private static Color getColor(String rgb) {
		if (rgb.startsWith("#"))
			rgb = rgb.substring(1);
		if (rgb.length() == 3) {
			return new Color(
					readHex(rgb.charAt(0), rgb.charAt(0)),
					readHex(rgb.charAt(1), rgb.charAt(1)),
					readHex(rgb.charAt(2), rgb.charAt(2))
				);
		}
		else if (rgb.length() == 6) {
			return new Color(
					readHex(rgb.charAt(0), rgb.charAt(1)),
					readHex(rgb.charAt(2), rgb.charAt(3)),
					readHex(rgb.charAt(4), rgb.charAt(5))
				);
		}
		else return null;
	}
	
	private static int readHex(char high, char low) {
		int i = 0;
		if (high <= '9') i += (high - '0');
		else  i += (high - 'A' + 10);
		i = i << 4;
		if (low <= '9') i += (low - '0');
		else  i += (low - 'A' + 10);
		return i;
	}
	
	private static String getHex(Color color) {
		return (getHex(color.getRed()) + getHex(color.getGreen()) + getHex(color.getBlue()));
	}
	
	private static String getHex(int i) {
		int high = (i >>> 4) & 15;
		int low = i & 15;
		String hex = "";
		if (high < 10) hex += ("" + high);
		else hex += ("" + ((char) ('A' + (high - 10))));
		if (low < 10) hex += ("" + low);
		else hex += ("" +  ((char) ('A' + (low - 10))));
		return hex;
	}
	
	private static class ImDocumentEditorUI extends JFrame {
		Settings config;
		File path;
		
		JMenuBar mainMenu = new JMenuBar();
		JMenu undoMenu = new JMenu("Undo");
		
		JFileChooser fileChooser = new JFileChooser();
		
		PageImageStore pageImageStore;
		PdfExtractor pdfExtractor;
		
		JTabbedPane docTabs = new JTabbedPane();
		
		ImDocumentEditorUI(String title, Settings config, File path) {
			super(title);
			this.config = config;
			this.path = path;
			
			final File pageImageFolder = new File(this.path, "PageImages");
			if (!pageImageFolder.exists())
				pageImageFolder.mkdirs();
			this.pageImageStore = new AbstractPageImageStore() {
				public boolean isPageImageAvailable(String name) {
					if (!name.endsWith(IMAGE_FORMAT))
						name += ("." + IMAGE_FORMAT);
					File pif = new File(pageImageFolder, name);
					return pif.exists();
				}
				public PageImageInputStream getPageImageAsStream(String name) throws IOException {
					if (!name.endsWith(IMAGE_FORMAT))
						name += ("." + IMAGE_FORMAT);
					File pif = new File(pageImageFolder, name);
					if (pif.exists())
						return new PageImageInputStream(new BufferedInputStream(new FileInputStream(pif)), this);
					else return null;
				}
				public boolean storePageImage(String name, PageImage pageImage) throws IOException {
					if (!name.endsWith(IMAGE_FORMAT))
						name += ("." + IMAGE_FORMAT);
					try {
						File pif = new File(pageImageFolder, name);
						if (pif.exists()) {
							String pifName = pif.getAbsolutePath();
							pif.renameTo(new File(pifName + "." + System.currentTimeMillis() + ".old"));
							pif = new File(pifName);
						}
						OutputStream imageOut = new BufferedOutputStream(new FileOutputStream(pif));
						pageImage.write(imageOut);
						imageOut.close();
						return true;
					}
					catch (IOException ioe) {
						ioe.printStackTrace(System.out);
						return false;
					}
				}
				public int getPriority() {
					return 0; // we're a general page image store, yield to specific ones
				}
			};
			PageImage.addPageImageSource(this.pageImageStore);
			
			this.pdfExtractor = new PdfExtractor(path, this.pageImageStore, true);
			
			this.fileChooser.setMultiSelectionEnabled(false);
			this.fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			this.fileChooser.setSelectedFile(new File(this.config.getSetting("lastDocFolder", path.getAbsolutePath())));
			
			this.addFileMenu();
			this.addExportMenu();
			this.addMenu(this.undoMenu);
			
			this.getContentPane().setLayout(new BorderLayout());
			this.getContentPane().add(this.mainMenu, BorderLayout.NORTH);
			this.getContentPane().add(this.docTabs, BorderLayout.CENTER);
			this.setSize(1000, 800);
			this.setLocationRelativeTo(null);
		}
		
		private void addFileMenu() {
			JMenu menu = new JMenu("File");
			JMenuItem mi;
			
			mi = new JMenuItem("Open Document");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					clearFileFilters(fileChooser);
					fileChooser.addChoosableFileFilter(imfFileFilter);
					fileChooser.addChoosableFileFilter(genericPdfFileFilter);
					fileChooser.addChoosableFileFilter(textPdfFileFilter);
					fileChooser.addChoosableFileFilter(imagePdfFileFilter);
					if (fileChooser.showOpenDialog(ImDocumentEditorUI.this) != JFileChooser.APPROVE_OPTION)
						return;
					File file = fileChooser.getSelectedFile();
					try {
						InputStream in = new BufferedInputStream(new FileInputStream(file));
						loadDocument(file, fileChooser.getFileFilter(), in);
						in.close();
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog(ImDocumentEditorUI.this, ("An error occurred while loading a document from '" + file.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Loading Document", JOptionPane.ERROR_MESSAGE);
						ioe.printStackTrace(System.out);
					}
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("Save Document");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					if (idet.save())
						return;
					idet.saveAs(fileChooser);
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("Save Document As");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					idet.saveAs(fileChooser);
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("Close Document");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					closeDocument();
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("Exit");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					exit();
				}
			});
			menu.add(mi);
			
			this.addMenu(menu);
		}
		
		private void addExportMenu() {
			JMenu menu = new JMenu("Export");
			JMenuItem mi;
			
			mi = new JMenuItem("As XML (without element IDs)");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					clearFileFilters(fileChooser);
					fileChooser.addChoosableFileFilter(xmlFileFilter);
					if (fileChooser.showSaveDialog(ImDocumentEditorUI.this) != JFileChooser.APPROVE_OPTION)
						return;
					File file = fileChooser.getSelectedFile();
					if (file.isDirectory())
						return;
					try {
						exportXml(idet.idvp.document, file, ImDocumentRoot.NORMALIZATION_LEVEL_PARAGRAPHS, false, false);
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog(ImDocumentEditorUI.this, ("An error occurred while exporting the document to '" + file.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Exporting Document", JOptionPane.ERROR_MESSAGE);
						ioe.printStackTrace(System.out);
					}
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("As XML (with element IDs)");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					clearFileFilters(fileChooser);
					fileChooser.addChoosableFileFilter(xmlFileFilter);
					if (fileChooser.showSaveDialog(ImDocumentEditorUI.this) != JFileChooser.APPROVE_OPTION)
						return;
					File file = fileChooser.getSelectedFile();
					if (file.isDirectory())
						return;
					try {
						exportXml(idet.idvp.document, file, ImDocumentRoot.NORMALIZATION_LEVEL_PARAGRAPHS, true, false);
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog(ImDocumentEditorUI.this, ("An error occurred while exporting the document to '" + file.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Exporting Document", JOptionPane.ERROR_MESSAGE);
						ioe.printStackTrace(System.out);
					}
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("As Raw XML (without element IDs)");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					clearFileFilters(fileChooser);
					fileChooser.addChoosableFileFilter(xmlFileFilter);
					if (fileChooser.showSaveDialog(ImDocumentEditorUI.this) != JFileChooser.APPROVE_OPTION)
						return;
					File file = fileChooser.getSelectedFile();
					if (file.isDirectory())
						return;
					try {
						exportXml(idet.idvp.document, file, ImDocumentRoot.NORMALIZATION_LEVEL_RAW, false, true);
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog(ImDocumentEditorUI.this, ("An error occurred while exporting the document to '" + file.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Exporting Document", JOptionPane.ERROR_MESSAGE);
						ioe.printStackTrace(System.out);
					}
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("As Raw XML (with element IDs)");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					clearFileFilters(fileChooser);
					fileChooser.addChoosableFileFilter(xmlFileFilter);
					if (fileChooser.showSaveDialog(ImDocumentEditorUI.this) != JFileChooser.APPROVE_OPTION)
						return;
					File file = fileChooser.getSelectedFile();
					if (file.isDirectory())
						return;
					try {
						exportXml(idet.idvp.document, file, ImDocumentRoot.NORMALIZATION_LEVEL_RAW, true, true);
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog(ImDocumentEditorUI.this, ("An error occurred while exporting the document to '" + file.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Exporting Document", JOptionPane.ERROR_MESSAGE);
						ioe.printStackTrace(System.out);
					}
				}
			});
			menu.add(mi);
			
			mi = new JMenuItem("As GAMTA XML");
			mi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					ImDocumentEditorTab idet = getActiveDocument();
					if (idet == null)
						return;
					clearFileFilters(fileChooser);
					fileChooser.addChoosableFileFilter(xmlFileFilter);
					if (fileChooser.showSaveDialog(ImDocumentEditorUI.this) != JFileChooser.APPROVE_OPTION)
						return;
					File file = fileChooser.getSelectedFile();
					if (file.isDirectory())
						return;
					try {
						ImDocumentRoot doc = new ImDocumentRoot(idet.idvp.document, ImDocumentRoot.NORMALIZATION_LEVEL_PARAGRAPHS);
						doc.setUseRandomAnnotationIDs(false);
						doc.setShowTokensAsWordsAnnotations(true);
						Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
						GenericGamtaXML.storeDocument(doc, out);
						out.close();
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog(ImDocumentEditorUI.this, ("An error occurred while exporting the document to '" + file.getAbsolutePath() + "':\n" + ioe.getMessage()), "Error Exporting Document", JOptionPane.ERROR_MESSAGE);
						ioe.printStackTrace(System.out);
					}
				}
			});
			menu.add(mi);
			
			this.addMenu(menu);
		}
		
		private void exportXml(ImDocument doc, File file, int normalizationLevel, boolean exportIDs, boolean exportWords) throws IOException {
			ImDocumentRoot xmlDoc = new ImDocumentRoot(doc, normalizationLevel);
			xmlDoc.setUseRandomAnnotationIDs(false);
			xmlDoc.setShowTokensAsWordsAnnotations(exportWords);
			Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
			AnnotationUtils.writeXML(xmlDoc, out, exportIDs);
			out.close();
		}
		
		void addMenu(JMenu menu) {
			this.mainMenu.add(menu);
		}
		
		void updateUndoMenu(final LinkedList undoActions) {
			this.undoMenu.removeAll();
			for (Iterator uait = undoActions.iterator(); uait.hasNext();) {
				final UndoAction ua = ((UndoAction) uait.next());
				JMenuItem mi = new JMenuItem(ua.label);
				mi.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ae) {
						while (undoActions.size() != 0) {
							UndoAction eua = ((UndoAction) undoActions.removeFirst());
							eua.execute();
							if (eua == ua)
								break;
						}
						updateUndoMenu(undoActions);
						ua.target.idvp.validate();
						ua.target.idvp.repaint();
						ua.target.idvp.validateControlPanel();
					}
				});
				this.undoMenu.add(mi);
				if (this.undoMenu.getMenuComponentCount() >= 10)
					break;
			}
			this.undoMenu.setEnabled(undoActions.size() != 0);
		}
		
		void loadDocument(final File file, final FileFilter fileFilter, final InputStream in) throws IOException {
			this.config.setSetting("lastDocFolder", file.getParentFile().getAbsolutePath());
			
			if (file.getName().toLowerCase().endsWith(".imf")) {
				this.addDocument(new ImDocumentEditorTab(ImDocumentEditorUI.this, file, ImfIO.loadDocument(in)));
				in.close();
				return;
			}
			
			if (file.getName().toLowerCase().endsWith(".pdf")) {
				final IOException[] loadException = {null};
				final SplashScreen loadScreen = new SplashScreen(this, ("Loading PDF '" + file.getName() + "'"), "", true, false);
				Thread loadThread = new Thread() {
					public void run() {
						try {
							loadScreen.setStep("Loading PDF data");
							ByteArrayOutputStream baos = new ByteArrayOutputStream();
							byte[] buffer = new byte[1024];
							int read;
							while ((read = in.read(buffer, 0, buffer.length)) != -1)
								baos.write(buffer, 0, read);
							in.close();
							
							ImDocument doc;
							if (fileFilter == textPdfFileFilter)
								doc = pdfExtractor.loadTextPdf(baos.toByteArray(), loadScreen);
							else if (fileFilter == imagePdfFileFilter)
								doc = pdfExtractor.loadImagePdf(baos.toByteArray(), loadScreen);
							else doc = pdfExtractor.loadGenericPdf(baos.toByteArray(), loadScreen);
							addDocument(new ImDocumentEditorTab(ImDocumentEditorUI.this, file, doc));
						}
						catch (IOException ioe) {
							loadException[0] = ioe;
						}
						finally {
							loadScreen.dispose();
						}
					}
				};
				loadThread.start();
				loadScreen.setVisible(true);
				if (loadException[0] == null)
					return;
				else throw loadException[0];
			}
		}
		
		void addDocument(ImDocumentEditorTab idet) {
			Settings annotationColors = this.config.getSubset("annotation.color");
			String[] annotationTypes = annotationColors.getKeys();
			for (int t = 0; t < annotationTypes.length; t++) {
				Color ac = getColor(annotationColors.getSetting(annotationTypes[t]));
				if (ac != null)
					idet.idvp.setAnnotationColor(annotationTypes[t], ac);
			}
			Settings layoutObjectColors = this.config.getSubset("layoutObject.color");
			String[] layoutObjectTypes = layoutObjectColors.getKeys();
			for (int t = 0; t < layoutObjectTypes.length; t++) {
				Color loc = getColor(layoutObjectColors.getSetting(layoutObjectTypes[t]));
				if (loc != null)
					idet.idvp.setLayoutObjectColor(layoutObjectTypes[t], loc);
			}
			Settings textStreamColors = this.config.getSubset("textStream.color");
			String[] textStreamTypes = textStreamColors.getKeys();
			for (int t = 0; t < textStreamTypes.length; t++) {
				Color tsc = getColor(textStreamColors.getSetting(textStreamTypes[t]));
				if (tsc != null)
					idet.idvp.setTextStreamTypeColor(textStreamTypes[t], tsc);
			}
			this.docTabs.addTab(idet.getDocumentName(), idet);
		}
		
		void removeDocument(ImDocumentEditorTab idet) {
			this.docTabs.remove(idet);
		}
		
		ImDocumentEditorTab getActiveDocument() {
			return ((this.docTabs.getComponentCount() == 0) ? null : ((ImDocumentEditorTab) this.docTabs.getSelectedComponent()));
		}
		
		boolean closeDocument() {
			ImDocumentEditorTab idet = getActiveDocument();
			if (idet == null)
				return true;
			if (idet.isDirty()) {
				int choice = JOptionPane.showConfirmDialog(ImDocumentEditorUI.this, ("Document '" + idet.getDocumentName() + "' has un-saved changes. Save them before closing it?"), "Save Changes?", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
				if (choice == JOptionPane.CANCEL_OPTION)
					return false;
				if (choice == JOptionPane.YES_OPTION) {
					if (!idet.save() && !idet.saveAs(this.fileChooser))
						return false;
				}
			}
			idet.close();
			return true;
		}
		
		void exit() {
			while (this.getActiveDocument() != null) {
				if (!this.closeDocument())
					return;
			}
			this.pdfExtractor.shutdown();
			PageImage.removePageImageSource(this.pageImageStore);
			try {
				Settings.storeSettingsAsText(new File(this.path, "GgImagine.cnfg"), this.config);
			} catch (IOException ioe) {}
			System.exit(0);
		}
	}
	
	private static abstract class UndoAction {
		final String label;
		final ImDocumentEditorTab target;
		final int modCount;
		UndoAction(String label, ImDocumentEditorTab target) {
			this.label = label;
			this.target = target;
			this.modCount = this.target.modCount;
		}
		final void execute() {
			try {
				this.target.inUndoAction = true;
				this.doExecute();
				this.target.modCount = this.modCount;
			}
			finally {
				this.target.inUndoAction = false;
			}
		}
		abstract void doExecute();
	}
	private static class MultipartUndoAction extends UndoAction {
		private LinkedList parts = new LinkedList();
		MultipartUndoAction(String label, ImDocumentEditorTab target) {
			super(label, target);
		}
		void addUndoAction(UndoAction ua) {
			this.parts.addFirst(ua);
		}
		void doExecute() {
			while (this.parts.size() != 0)
				((UndoAction) this.parts.removeFirst()).doExecute();
		}
	}
	
	private static class ImDocumentEditorTab extends JPanel {
		ImDocumentEditorUI parent;
		File file;
		ImDocumentMarkupPanel idvp;
		
		ImDocumentListener undoRecorder;
		LinkedList undoActions = new LinkedList();
		MultipartUndoAction multipartUndoAction = null;
		boolean inUndoAction = false;
		
		int modCount = 0;
		int savedModCount = 0;
		
		ImDocumentEditorTab(ImDocumentEditorUI parent, File source, ImDocument doc) {
			super(new BorderLayout(), true);
			this.parent = parent;
			this.file = source;
			this.idvp = new ImDocumentMarkupPanel(doc);
			
			//	update undo menu in parent
			this.addFocusListener(new FocusAdapter() {
				public void focusGained(FocusEvent fe) {
					ImDocumentEditorTab.this.parent.updateUndoMenu(undoActions);
				}
			});
			
			//	prepare recording UNDO actions
			this.undoRecorder = new ImDocumentListener() {
				public void typeChanged(final ImObject object, final String oldType) {
					if (inUndoAction)
						return;
					addUndoAction(new UndoAction(("Change Object Type to '" + object.getType() + "'"), ImDocumentEditorTab.this) {
						void doExecute() {
							object.setType(oldType);
						}
					});
				}
				public void regionAdded(final ImRegion region) {
					if (inUndoAction)
						return;
					addUndoAction(new UndoAction(("Add '" + region.getType() + "' Region"), ImDocumentEditorTab.this) {
						void doExecute() {
							region.getDocument().getPage(region.pageId).removeRegion(region);
						}
					});
				}
				public void regionRemoved(final ImRegion region) {
					if (inUndoAction)
						return;
					if (region instanceof ImWord)
						addUndoAction(new UndoAction(("Remove Word '" + region.getAttribute(ImWord.STRING_ATTRIBUTE) + "'"), ImDocumentEditorTab.this) {
							void doExecute() {
								region.getDocument().getPage(region.pageId).addRegion(region);
							}
						});
					else addUndoAction(new UndoAction(("Remove '" + region.getType() + "' Region"), ImDocumentEditorTab.this) {
						void doExecute() {
							region.getDocument().getPage(region.pageId).addRegion(region);
						}
					});
				}
				public void attributeChanged(final ImObject object, final String attributeName, final Object oldValue) {
					if (inUndoAction)
						return;
					if (oldValue == null)
						addUndoAction(new UndoAction(("Add " + attributeName + " Attribute to " + object.getType()), ImDocumentEditorTab.this) {
							void doExecute() {
								object.removeAttribute(attributeName);
							}
						});
					else if (object.getAttribute(attributeName) == null)
						addUndoAction(new UndoAction(("Remove '" + attributeName + "' Attribute from " + object.getType()), ImDocumentEditorTab.this) {
							void doExecute() {
								object.setAttribute(attributeName, oldValue);
							}
						});
					else addUndoAction(new UndoAction(("Change '" + attributeName + "' Attribute of " + object.getType() + " to '" + object.getAttribute(attributeName).toString() + "'"), ImDocumentEditorTab.this) {
						void doExecute() {
							object.setAttribute(attributeName, oldValue);
						}
					});
				}
				public void annotationAdded(final ImAnnotation annotation) {
					if (inUndoAction)
						return;
					addUndoAction(new UndoAction(("Add '" + annotation.getType() + "' Annotation"), ImDocumentEditorTab.this) {
						void doExecute() {
							/* We need to re-get annotation and make our own
							 * comparison, as removing and re-adding thwarts
							 * this simple approach */
							ImAnnotation[] annots = annotation.getDocument().getAnnotations(annotation.getFirstWord(), null);
							for (int a = 0; a < annots.length; a++) {
								if (!annots[a].getLastWord().getLocalID().equals(annotation.getLastWord().getLocalID()))
									continue;
								if (!annots[a].getType().equals(annotation.getType()))
									continue;
								annotation.getDocument().removeAnnotation(annots[a]);
								break;
							}
						}
					});
				}
				public void annotationRemoved(final ImAnnotation annotation) {
					if (inUndoAction)
						return;
					addUndoAction(new UndoAction(("Remove '" + annotation.getType() + "' Annotation"), ImDocumentEditorTab.this) {
						void doExecute() {
							annotation.getDocument().addAnnotation(annotation.getFirstWord(), annotation.getLastWord(), annotation.getType()).copyAttributes(annotation);
						}
					});
				}
			};
			this.idvp.document.addDocumentListener(this.undoRecorder);
			
			this.idvp.setRenderingDpi(150);
			this.idvp.setSideBySidePages(1);
			this.idvp.setTextStreamsPainted(true);
			JScrollPane idvpBox = new JScrollPane();
			idvpBox.getVerticalScrollBar().setUnitIncrement(50);
			idvpBox.getVerticalScrollBar().setBlockIncrement(50);
			idvpBox.setViewport(new IdvpViewport(this.idvp));
			this.add(idvpBox, BorderLayout.CENTER);
			this.add(this.idvp.getControlPanel(), BorderLayout.EAST);
		}
		
		private void addUndoAction(UndoAction ua) {
			if (this.inUndoAction)
				return;
			if (this.multipartUndoAction == null) {
				this.modCount++;
				this.undoActions.addFirst(ua);
				this.parent.updateUndoMenu(this.undoActions);
			}
			else this.multipartUndoAction.addUndoAction(ua);
		}
		
		private void startMultipartUndoAction(String label) {
			this.multipartUndoAction = new MultipartUndoAction(label, this);
		}
		
		private void finishMultipartUndoAction() {
			if (this.multipartUndoAction != null) {
				this.modCount++;
				this.undoActions.addFirst(this.multipartUndoAction);
				this.parent.updateUndoMenu(this.undoActions);
			}
			this.multipartUndoAction = null;
		}
		
		private static class IdvpViewport extends JViewport implements TwoClickActionMessenger {
			private static Color halfTransparentRed = new Color(Color.red.getRed(), Color.red.getGreen(), Color.red.getBlue(), 128);
			private ImDocumentMarkupPanel idvp;
			private String tcaMessage = null;
			IdvpViewport(ImDocumentMarkupPanel idvp) {
				this.idvp = idvp;
				this.idvp.setTwoClickActionMessenger(this);
				this.setView(this.idvp);
				this.setOpaque(false);
			}
			public void twoClickActionChanged(TwoClickSelectionAction tcsa) {
				this.tcaMessage = ((tcsa == null) ? null : tcsa.getActiveLabel());
				this.validate();
				this.repaint();
			}
			public void paint(Graphics g) {
				super.paint(g);
				if (this.tcaMessage == null)
					return;
				Font f = new Font("Helvetica", Font.PLAIN, 20);
				g.setFont(f);
				TextLayout wtl = new TextLayout(this.tcaMessage, f, ((Graphics2D) g).getFontRenderContext());
				g.setColor(halfTransparentRed);
				g.fillRect(0, 0, this.getViewRect().width, ((int) Math.ceil(wtl.getBounds().getHeight() + (wtl.getDescent() * 3))));
				g.setColor(Color.white);
				((Graphics2D) g).drawString(this.tcaMessage, ((this.getViewRect().width - wtl.getAdvance()) / 2), ((int) Math.ceil(wtl.getBounds().getHeight() + wtl.getDescent())));
			}
		}
		
		void applyDocumentProcessor(final DocumentProcessor dp) {
			
			//	create splash screen
			final SplashScreen dpSplashScreen = new SplashScreen(this.parent, ("Running " + dp.getTypeLabel() + " '" + dp.getName() + "', Please Wait"), "", false, true);
			
			//	initialize atomic UNDO
			this.startMultipartUndoAction("Run " + dp.getTypeLabel() + " '" + dp.getName() + "'");
			
			//	apply document processor, in separate thread
			Thread dpThread = new Thread() {
				public void run() {
					try {
						
						//	wait for splash screen to come up (we must not reach the dispose() line before the splash screen even comes up)
						while (!dpSplashScreen.isVisible()) try {
							Thread.sleep(10);
						} catch (InterruptedException ie) {}
						
						//	wrap document
						ImDocumentRoot doc = new ImDocumentRoot(idvp.document, ImDocumentRoot.NORMALIZATION_LEVEL_PARAGRAPHS); // TODO make normalization level configurable
						
						//	create parameters
						Properties parameters = new Properties();
						parameters.setProperty(DocumentProcessor.INTERACTIVE_PARAMETER, DocumentProcessor.INTERACTIVE_PARAMETER);
						
						//	apply document processor
						dp.process(doc, parameters);
					}
					
					//	catch whatever might happen
					catch (Throwable t) {
						t.printStackTrace(System.out);
						JOptionPane.showMessageDialog(dpSplashScreen, ("Error running " + dp.getName() + ":\n" + t.getMessage()), "Error Running DocumentProcessor", JOptionPane.ERROR_MESSAGE);
					}
					
					finally {
						
						//	finish atomic UNDO
						finishMultipartUndoAction();
						
						//	dispose splash screen
						dpSplashScreen.dispose();
						
						//	make changes show
						idvp.validate();
						idvp.repaint();
						idvp.validateControlPanel();
					}
				}
			};
			dpThread.start();
			
			//	open splash screen (this waits)
			dpSplashScreen.setVisible(true);
		}
		
		String getDocumentName() {
			if (this.file != null)
				return this.file.getName();
			else return ((String) this.idvp.document.getAttribute(DOCUMENT_NAME_ATTRIBUTE, "Unknown Document"));
		}
		
		boolean isDirty() {
			return (this.modCount != this.savedModCount);
		}
		
		boolean save() {
			return (this.isDirty() ? this.saveAs(this.file) : true);
		}
		
		boolean saveAs(JFileChooser fileChooser) {
			clearFileFilters(fileChooser);
			fileChooser.addChoosableFileFilter(imfFileFilter);
			if (this.file != null)
				fileChooser.setSelectedFile(this.file);
			if (fileChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION)
				return false;
			File file = fileChooser.getSelectedFile();
			if (file.isDirectory())
				return false;
			return this.saveAs(file);
		}
		
		boolean saveAs(File file) {
			
			//	check file name
			if (!file.getName().endsWith(".imf"))
				file = new File(file.getAbsolutePath() + ".imf");
			
			//	create splash screen
			final SplashScreen saveSplashScreen = new SplashScreen(this.parent, "Saving Document, Please Wait", "", false, false);
			
			//	save document, in separate thread
			final boolean[] saveSuccess = {false};
			final File[] saveFile = {file};
			Thread saveThread = new Thread() {
				public void run() {
					try {
						
						//	wait for splash screen to come up (we must not reach the dispose() line before the splash screen even comes up)
						while (!saveSplashScreen.isVisible()) try {
							Thread.sleep(10);
						} catch (InterruptedException ie) {}
						
						//	make way
						if (saveFile[0].exists()) {
							String fileName = saveFile[0].getAbsolutePath();
							saveFile[0].renameTo(new File(fileName + "." + System.currentTimeMillis() + ".old"));
							saveFile[0] = new File(fileName);
						}
						
						//	save document
						OutputStream out = new BufferedOutputStream(new FileOutputStream(saveFile[0]));
						ImfIO.storeDocument(ImDocumentEditorTab.this.idvp.document, out);
						out.flush();
						out.close();
						ImDocumentEditorTab.this.savedModCount = ImDocumentEditorTab.this.modCount;
						ImDocumentEditorTab.this.file = saveFile[0];
						ImDocumentEditorTab.this.parent.docTabs.setTitleAt(ImDocumentEditorTab.this.parent.docTabs.indexOfComponent(ImDocumentEditorTab.this), ImDocumentEditorTab.this.file.getName());
						saveSuccess[0] = true;
					}
					
					//	catch whatever might happen
					catch (Throwable t) {
						JOptionPane.showMessageDialog(ImDocumentEditorTab.this, ("An error occurred while saving the document to '" + saveFile[0].getAbsolutePath() + "':\n" + t.getMessage()), "Error Saving Document", JOptionPane.ERROR_MESSAGE);
						t.printStackTrace(System.out);
					}
					
					//	dispose splash screen
					finally {
						saveSplashScreen.dispose();
					}
				}
			};
			saveThread.start();
			
			//	open splash screen (this waits)
			saveSplashScreen.setVisible(true);
			
			//	finally ...
			return saveSuccess[0];
		}
		
		void close() {
			this.idvp.document.removeDocumentListener(this.undoRecorder);
			this.parent.removeDocument(this);
			Settings annotationColors = this.parent.config.getSubset("annotation.color");
			String[] annotationTypes = this.idvp.getAnnotationTypes();
			for (int t = 0; t < annotationTypes.length; t++) {
				Color ac = this.idvp.getAnnotationColor(annotationTypes[t]);
				if (ac != null)
					annotationColors.setSetting(annotationTypes[t], getHex(ac));
			}
			Settings layoutObjectColors = this.parent.config.getSubset("layoutObject.color");
			String[] layoutObjectTypes = this.idvp.getLayoutObjectTypes();
			for (int t = 0; t < layoutObjectTypes.length; t++) {
				Color loc = this.idvp.getLayoutObjectColor(layoutObjectTypes[t]);
				if (loc != null)
					layoutObjectColors.setSetting(layoutObjectTypes[t], getHex(loc));
			}
			Settings textStreamColors = this.parent.config.getSubset("textStream.color");
			String[] textStreamTypes = this.idvp.getTextStreamTypes();
			for (int t = 0; t < textStreamTypes.length; t++) {
				Color tsc = this.idvp.getTextStreamTypeColor(textStreamTypes[t]);
				if (tsc != null)
					textStreamColors.setSetting(textStreamTypes[t], getHex(tsc));
			}
		}
	}
	
	private static class SplashScreen extends JDialog implements ControllingProgressMonitor {
		private JLabel textLabel = new JLabel("Please wait while GoldenGATE Resource is running ...", JLabel.LEFT);
		private ProgressMonitorPanel pmp;
		
		SplashScreen(JFrame owner, String title, String text, boolean supportPauseResume, boolean supportAbort) {
			super(owner, title, true);
			this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			
			this.pmp = new ProgressMonitorPanel(supportPauseResume, supportAbort);
			
			this.setLayout(new BorderLayout());
			this.add(this.textLabel, BorderLayout.NORTH);
			this.add(this.pmp, BorderLayout.CENTER);
			
			this.setSize(new Dimension(400, ((supportPauseResume || supportAbort) ? 150 : 130)));
			this.setLocationRelativeTo(owner);
			if (text != null)
				this.setText(text);
		}
		
		public void setAbortExceptionMessage(String aem) {
			this.pmp.setAbortExceptionMessage(aem);
		}
		
		public boolean supportsAbort() {
			return this.pmp.supportsAbort();
		}
		
		public void setAbortEnabled(boolean ae) {
			this.pmp.setAbortEnabled(ae);
		}
		
		public boolean supportsPauseResume() {
			return this.pmp.supportsPauseResume();
		}
		
		public void setPauseResumeEnabled(boolean pre) {
			this.pmp.setPauseResumeEnabled(pre);
		}
		
		public void setStep(String step) {
			this.pmp.setStep(step);
		}
		
		public void setInfo(String info) {
			this.pmp.setInfo(info);
		}
		
		public void setBaseProgress(int baseProgress) {
			this.pmp.setBaseProgress(baseProgress);
		}
		
		public void setMaxProgress(int maxProgress) {
			this.pmp.setMaxProgress(maxProgress);
		}
		
		public void setProgress(int progress) {
			this.pmp.setProgress(progress);
		}
		
		/**
		 * Set the text displayed on the label of the splash screen
		 * @param text the new text
		 */
		public void setText(String text) {
			this.textLabel.setText((text == null) ? "" : text);
		}
	}
}